<html>  
    <body>  
    <form method="post"> 
        <input type="number" name="num1">  
        <input type="number" name="num2"> 
        <input type="submit" name="submit" value="Submit">  
    </form>  
    </body>  
    </html> 
    <?php
    if(isset($_POST['submit'])){
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        //  you have to initialize before using condition
        for($num1 = $num1; $num1 <= $num2;){
            //  here is the condition to check the EVEN number
            if($num1%2!==0){
                echo $num1."<br>";
                }
                // increasing the loope counter by 1
            $num1++;
        }
    }
    ?>