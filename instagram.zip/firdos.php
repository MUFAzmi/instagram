<script type="text/javascript">


function changeButton() {
	document.getElementById("changeling").name="Display";
	document.getElementById("changeling").value="Display";
	document.getElementById("changeling").onclick=function() { display() };

}

function edit() {
	alert("edit function");
}

function display() {
	alert("display function");
}


</script>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<TITLE>test</TITLE>
</head>

<body>
	<form name="formName">
		<input type="button" name="Add" value="Add" onclick="changeButton();" >
		<br/>
		<input type="button" id="changeling" name="Edit" value="Edit" onclick="edit();" >
	</form>
</body>
</html>