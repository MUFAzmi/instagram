<select name="cmbitems" id="cmbitems">
    <option value="price1">blue</option>
    <option value="price2">green</option>
    <option value="price3">red</option>
</select>
<input type="text" name="txtprice" id="txtprice" onClick="checkPrice()">
