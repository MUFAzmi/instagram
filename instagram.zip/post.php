     <!-- **************************************POST SECTION************************************* -->
<?php require_once('include/header.php'); ?>
     <?php
        if(isset($_GET['p'])){

        }
        else{
            header("location:index.php");
        }
     ?>
           
     <?php
                        // fetching posts content form database server using get post id 
                        $get_p_id = htmlentities(mysqli_real_escape_string($con,$_GET['p']));
                        $query = "SELECT * FROM `posts` WHERE `post_id` = '$get_p_id'";
                        $run = mysqli_query($con,$query);
                        while($data = mysqli_fetch_assoc($run)){
                        $content = htmlentities(mysqli_real_escape_string($con,$data['content']));
                        $image = htmlentities(mysqli_real_escape_string($con,$data['image'])); 
                    ?>
                <div class="card z-depth-1">
                    <div class="" style="">
                                        <div class="col s2 m2 l2 center">
                                                <img src="img/mufazmi.png" style="width: 35px; margin-top:5px" class="left responsive-img circle" alt="">
                                            </div>
                                            <div class="col s8 m8 l8">
                                                <span class="left" style="margin-top: 10px; margin-bottom:15px;"><?php echo $_SESSION['name']; ?></span>
                                            </div>
                                            <div class="col s2 m2 l2">
                                                <a href="#" data-target="post_dropdown" class="dropdown-trigger"> <i class="material-icons right"class=""style="margin-top: 13px; ">more_vert</i></a>
                                                <ul class="dropdown-content" id="post_dropdown">
                                                    <li>Edit</li>
                                                    <li>Delete</li>
                                                </ul>
                                            </div>
                    </div>
                            <img src="img/<?php echo $image; ?>" class="responsive-img"  alt="">
                            <div class="content">
                                <p>
                                    <?php echo $content; ?>
                                </p>
                            </div>
                            <div class="row">
                                <form>
                                    <div class="col s1">
                                        <?php 
                                            // fetching that user liked this post or not, if likes then we will print dislike button 
                                            // $query = "SELECT * FROM `likes` WHERE `from_user_id`='$sender_id' AND `post_id` = '$post_id'";
                                            // $run = mysqli_query($con, $query);
                                            // $row = mysqli_rows($run);
                                        ?>
                                        <input type="hidden" name="" id="post_id" value=" <?php echo $post_id; ?> ">
                                        <input type="hidden" name="" id="sender_id" value="<?php echo $session_id; ?>">
                                        <a href=""><i class="material-icons" style=" transparent" onclick=" return sendLikes();" >favorite_border</i></a>
                                      
                                    </div>
                                </form>
                                <div class="col s1">
                                    <a href=""><i class="material-icons">message</i></a>
                                </div>
                                <div class="col s1">
                                    <a href=""><i class="material-icons">send</i></a>
                                </div>
                            </div>
                </div>
                        <?php } ?>
            </div>
            </body>
            <?php require_once('include/footer.php'); ?>