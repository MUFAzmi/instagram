<?php
    session_start();
    header("LOCATION:dashboard");
?>