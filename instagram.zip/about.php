<?php require_once('include/header.php'); ?>
<body class="red darken-5" style="background-image: url(images/2.jpg);">
<div class="navbar-fixed" >
        <nav>
                <div class="row" >
                    <div class="col s12 l12 m12">
                        <span>&nbsp; &nbsp; About Us</span>
                    </div>
                </div>
            </nav>
</div>
</body>
<div class=" row">
    <div class="col s12 m8 offset-m2  l6 offset-l3"> 
        <div class="card z-depth-5  black yellow-text " style="margin-bottom:50px;" >
            <div class="card-image">
                <img src="images/2.jpg" alt="">
                <span class="card-title">&nbsp; About Social Codia..!</span>
            </div>
            <div class="card-content">
            The SOCIAL CODIA is a synonimous of SOCIAL MEDIA, ok <br>
            The SOCIAL CODIA's mission is to provide infomation all about Programming, Netwoking, Technology and Social Media. <br>
            we have a group of developers and this project is launched by one of our members, <br>

            you know, if you subscirbed, likes or follows our page then you are also a part of our community, <br>
            feel free if you are not a developer , programmer or any other post form infomation technology, then you also don't need to worry, <br>

            we will tech you freely, or if you are developer, programmer or any other post form infomation technology, then that's great news for us and both, <br>

             you have any doubt from any programming language, then please please this is our request we will also help you to solve any query, <br> <br>


            by the way, Let's finish, <br> <br>

            Thanks for following our page , and joining our community.
            </div>
        </div>
    </div>
</div>
<?php require_once('include/footer.php'); ?>