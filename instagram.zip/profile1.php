<?php require_once('include/header.php') ?>
 <!-- ***************************navbar code******************* -->
 <?php
    $query = "SELECT * FROM `post` WHERE `id` = $_session['id']";
    $run = mysqli_query($con,$query);
    while($data = mysqli_fetch_assoc($run)){
        $from_user_id = $data['from_user_id'];
        $post_image_name = $data['image'];
    }
 ?>

<div class="navbar-fixed">
        <nav>
                <div class="row">
                    <div class="col s1 l1 m1 ">
                        <a href="camera.html" class=" left"> <i class="material-icons">camera_alt</i> </a>
                    </div>
                    <div class="col s9 m9 l9">
                        <h5>Instagram</h5>
                    </div>
                    <div class="col s1 m1 l1">
                            <a href="video.html" class=""> <i class="material-icons">tv</i> </a>
                        </div>
                    <div class="col s1 m1 l1">
                        <a href="message.html" class=""> <i class="material-icons">send</i> </a>
                    </div>
                </div>
            </nav>
</div>
<main class="blue lighten-5">

        <div class="row">
            <div class="col s12 m3 l3 hide-on-down"> <br>
                <div class="card-panel z-depth-0 center">
                    <img src="img/mufazmi.png" class="responsive-img circle " style="width:130px; border: 2px solid brown;" alt="">
                    <h5 class="center">Umair Farooqui</h5>
                    <input type="submit" class="btn red" value="Follow" name="" id="">
                    <br> <br>
                    <div class="divider"></div>
                    <table>
                        <thead>
                            <tr>
                                <th>Followings</th>
                                <td>69</td>
                           
                                <th>Followers</th>
                                <td>569</td>
                            </tr>
                        </thead>
                    </table>
                    <div class="card-panel blue lighten-1">
                        <h4>About Me!</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil dolores illum totam, corporis minus molestiae aperiam? Fugit, eius aperiam? Quia?</p>
                    </div>
                </div>
            </div>
            <div class="col s12 m6 l6">
                <!-- story section --> <br>
                <div class="row">
                        <div class="col s2 m2 l2 ">
                            <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                            <span style="font-size: 10px; center">mufazmi</span>
                        </div>
                        <div class="col s2 m2 l2">
                                <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                                <span style="font-size: 10px; center">mufazmi</span>
                            </div>
                            <div class="col s2 m2 l2">
                                    <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                                    <span style="font-size: 10px; center">mufazmi</span>
                                </div>
                                <div class="col s2 m2 l2">
                                        <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                                        <span style="font-size: 10px; center">mufazmi</span>
                                    </div>
                                    <div class="col s2 m2 l2">
                                            <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                                            <span style="font-size: 10px; center">mufazmi</span>
                                        </div>
                                        <div class="col s2 m2 l2">
                                                <img src="img/mufazmi.png" style="width: 50px; border: 1px solid red; padding: 1px;;" class="responsive-img z-depth-1 circle" alt=""> <br>
                                                <span style="font-size: 10px; center">mufazmi</span>
                                            </div>
                    </div>
           <!-- **************************************POST SECTION************************************* -->
           
           <?php
                        // fetching posts content form database server
                        $query = "SELECT * FROM `posts` WHERE `from_user_id` = '$session_id'";
                        $run = mysqli_query($con,$query);
                        while($data = mysqli_fetch_assoc($run)){
                        $content = $data['content'];
                        $image = $data['image'];
                    
                    ?>
                <div class="card z-depth-0">
                    <div class="" style="">
                                        <div class="col s2 m2 l2 center">
                                                <img src="img/mufazmi.png" style="width: 35px; margin-top:5px" class="left responsive-img circle" alt="">
                                            </div>
                                            <div class="col s8 m8 l8">
                                                <span class="left" style="margin-top: 10px; margin-left: -26px;"><?php echo $_SESSION['name']; ?></span>
                                            </div>
                                            <div class="col s2 m2 l2">
                                                <a href="#" data-target="post_dropdown" class="dropdown-trigger"> <i class="material-icons right"class=""style="margin-top: 13px; ">more_vert</i></a>
                                                <ul class="dropdown-content" id="post_dropdown">
                                                    <li>Edit</li>
                                                    <li>Delete</li>
                                                </ul>
                                            </div>
                    </div>
                            <img src="img/<?php echo $image; ?>" class="responsive-img"  alt="">
                            <div class="content">
                                <p>
                                    <?php echo $content; ?>>
                                </p>
                            </div>
                            <div class="row">
                                <div class="col s1">
                                    <a href=""><i class="material-icons">favorite_border</i></a>
                                </div>
                                <div class="col s1">
                                    <a href=""><i class="material-icons">message</i></a>
                                </div>
                                <div class="col s1">
                                    <a href=""><i class="material-icons">send</i></a>
                                </div>
                            </div>
                </div>
                        <?php } ?>
            </div>
            <!-- *******************************SECTION RIGHT SIGHT*************************************** -->
            <div class="col s12 m3 l3"> <br>
                <div class="row">
                    <div class="card-panel z-depth-0">
                        <h5>Who to follow!</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias illo natus, velit eveniet reiciendis ipsam quaerat beatae consequuntur possimus numquam omnis consequatur blanditiis asperiores sapiente eos minima temporibus sequi, accusantium similique ab perferendis! Nulla veritatis aut repellat ducimus earum, omnis dolore, quae quisquam corrupti deleniti non. Non tempore amet molestias tempora molestiae ullam deserunt natus officiis ab eaque, inventore, explicabo fugiat, nihil quasi architecto quidem voluptatibus dolorum. Non cum magnam ipsum excepturi laborum, assumenda quisquam, et, perferendis cumque nisi commodi deserunt nemo? Quam voluptatum pariatur neque aliquam eius, ducimus excepturi laudantium. At quidem corporis quo earum delectus voluptates a quas minus sint soluta praesentium eligendi asperiores explicabo libero dolore, nam numquam eveniet fuga ex aspernatur neque aut minima? Adipisci incidunt itaque voluptatibus aliquam et ducimus sit similique sequi, doloremque quaerat eligendi commodi sapiente fuga excepturi consequuntur. Repudiandae excepturi necessitatibus ex omnis similique esse fugiat ipsam optio nam, nostrum deleniti accusantium minima! Quisquam rerum tempore cupiditate, illum rem voluptatum adipisci aut fugiat ipsam sapiente numquam eveniet odio iure voluptas assumenda quibusdam. Nesciunt ducimus quia labore ullam debitis a ipsam nisi corrupti quae possimus eaque porro aspernatur dolorem mollitia ex ab accusamus maiores, doloribus ratione voluptas odio tempore delectus. Sunt, laudantium illo?</p>
                    </div>
                </div>
            </div>
        </div>
        </main>
  <body>
      <!-- *************************footer code**************************** -->
<div class="footer-fixed">
        <footer>
<nav>
    <div class="nav-wrapper">
        <ul class="justify" style="display: table; margin: 0 auto;">
            <li style=" width: 85px;"><a href="index.html"><i class=" black-text material-icons">home</i></a></li>
            <li style=" width: 85px;"><a href="search.html"><i class="material-icons">search</i></a></li>
            <li style=" width: 85px;"><a href="camera.html"><i class="material-icons">add</i></a></li>
            <li style=" width: 85px;"><a href="notification.html"><i class="material-icons">favorite_border</i></a></li>
            <li><a href="profile.html"><i class="material-icons"><img src="img/mufazmi.png" style="width: 20px;" class="circle responsive-img" alt=""></i></a></li>
        </ul>
    </div>
</nav>
            </footer>
</div>
    <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script>
    $(document).ready(function(){
        $('.dropdown-trigger').dropdown();
    });
    </script>
  </body>
</html>