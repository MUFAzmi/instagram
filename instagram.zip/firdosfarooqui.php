<div id="divtouse">This is the value which you have selected:-  </div>

<form >
      <select name='select' id='select'>
        <option value=''>Select an option</option>
        <option value='1'>1</option>
        <option value='2'>2</option>
        <option value='firdos'>3</option>
        <option value='4'>4</option>
        <option value='5'>5</option>
        <option value='6'>6</option>
        <option value='7'>7</option>
        <option value='8'>8</option>
      </select>
    <input type='submit'  onClick='if(!checkdropdown()) {alert("You need to select a value!"); return false;}' value='Submit form' />
</form>

	<script>
            function checkdropdown() {
            if(document.getElementById('select').value != "") {
                    return true;
            }
            else {
                return false;
            }
            }
            select.onchange = function() 
            {   
                var selected = document.getElementById('select').value;
                var text;
                // document.getElementById("divtouse").textContent="This is the value which you have selected:- "+select.value;
                switch(selected){
                    case 1:
                        text = "you have selected one value";
                        document.getElementById("divtouse").textContent="This"+text;
                        break();
                    case 2:
                        text ="you have selected two";
                        document.getElementById("divtouse").textContent="This"+text;
                        break();
                    case "fidos":
                        text="hi firod is my life";
                        document.getElementById("divtouse").textContent="This"+text;
                        break();
                }
                
            }
	</script>