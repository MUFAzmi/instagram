<?php require_once('include/header.php') ?>
 <!-- ***************************navbar code******************* -->
<div class="navbar-fixed">
        <nav>
                <div class="row">
                    <div class="col s1 l1 m1 ">
                        <a href="dashboard" class=" left"> <i class="material-icons">arrow_back</i> </a>
                    </div>
                    <a href="profile">
                            <div class="col s8 m8 l8 left" style="margin-top: 10px;">
                                <b>IGTV</b>
                            </div>
                    </a>
                    <div class="col s1 m1 l1">
                            <a href="" class=""> <i class="material-icons">search</i> </a>
                        </div>
                    <div class="col s1 m1 l1">
                            <a href="" class=""> <i class="material-icons">add</i> </a>
                        </div>
                    <div class="col s1 m1 l1">
                        <a href="" class=""> <img src="img/<?php echo $image; ?>" style="width: 90px; margin-top:16px;" class="circle responsive-img" alt=""> </a>
                    </div>
                </div>
            </nav>
</div>
<main>
 
<div class="row">
    <br>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
    <div class="col s12 m6 l4">
        <video  class="responsive-video" controls>
            <source src="vid/zindagi.mp4" type="video/mp4">
        </video>
    </div>
</div>
        
</main>
  <body>
      <!-- *************************footer code**************************** -->
<?php require_once('include/footer.php') ?>