<?php 
require_once('include/dbcon.php');

    $query = "SELECT * FROM `likes` WHERE `from_user_id`= ";
?> 